import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet("/reqlogin")
public class Controller extends HttpServlet
{
	public void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException
	{
		String name=req.getParameter("t1");
		String pwd=req.getParameter("t2");
		PrintWriter out=res.getWriter();
		out.print("welcome" + name);
	}
}
