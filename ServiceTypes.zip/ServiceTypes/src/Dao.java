import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.http.HttpServlet;


public class Dao
{
	static Connection con=null;
	public static Connection getConnectionObject()
	{
		try
		{
			Class.forName("org.h2.Driver");
			con=DriverManager.getConnection("jdbc:h2:tcp://localhost/~/dao","dao","dao");
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return con;
	}
	public boolean login(String name,String pwd)
	{
		boolean b=false;
		con=Dao.getConnectionObject();
		try
		{
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery("select name,password from student where name='"+name+"' and password='"+pwd+"'");
			if(rs.next())
			{
				b=true;
			}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return b;
	}
	
}